 <!-- Masthead-->
        <header class="masthead">
            <div class="container h-100">
                <div class="row h-100 align-items-center justify-content-center text-center">
                    <div class="col-lg-10 align-self-end mb-4" style="background: #0000002e;">
                    	 <h1 class="text-uppercase text-white font-weight-bold">About Us</h1>
                        <hr class="divider my-4" />
                    </div>
                    
                </div>
            </div>
        </header>

    <section class="page-section">
        <div class="container">
           
           <h4> History</h4><br>

            <p>In 1916, Karnataka LingayatEducation(K. L. E.) Society was founded by the Seven Founder Life Members, who are also addressed as “Saptarishis”[Seven Saints]. On 13th November 1916, K.L.E. Society started an Anglo Vernacular School in Belgaum. Lingaraj College came into existence in June 1933. In 1947, B.V.B. College of Engineering and Technology was started in Hubli. J.N. Medical College at Belgaum and G.H. College at Haveri was started in the year 1963. From 1984 onwards, K.L.E. Society started Dental, Education, Nursing, Information Technology, Computer Applications, Hotel Management, Business Management, Tourism, Fashion Designing, Agriculture Colleges and Polytechnics across India. Today under the leadership of Mr. Prabhakar Kore an able and dynamic team leader KLE Society runs 207 institutions.
<br>
<br>

The founders of K.L.E.S pledged to dedicate for the cause of education with noble ideals and fertile imagination in heart & established KarnatakLingayatEducation Society. They are also addressed as “Saptarishis” [Seven Saints] in honour of their unparalleled service in the field of education.

The saga begins with its illustrious founders. Sri. ChachadiVeerabhadrappaGunappa Desai, ruler of chachadi province, Sri. ArtalRudragouda, District Deputy Collector in the British Government and Sri. VaijappaAnigol, RaoBahadur during the British Rule, who all collectively believed in providing education for the common man. Their efforts were ably supplemented by the seven visionaries- Sri. S. S. Basavanal, Sri. M. R. Sakhare, Sri. B. B. Mamadapur, Sri. H. F. Kattimani, Sri. PanditappaChikkodi, Sri. B. S. Hanchinal and Sri. SardarVeeranagoudaPatil, with the collective contribution from renowned philanthropists of the region, such as Sri. SirsangiLingaraj, Sri. Raja LakhamagoudaSardesai and Sri. BhoomaraddiBasappa and help from other philosophers, intellectuals and educationists, the society began laying a strong educational foundation, with its base at Belgaum, Karnataka.</p>
        </div>
        </section>