<?php include 'db_connect.php'; ?>

<?php
if (isset($_GET['id'])) {
    $event_id = $_GET['id'];
    // Fetch event details
    $event_qry = $conn->query("SELECT * FROM events WHERE id = $event_id");
    $event = $event_qry->fetch_assoc();

    // Fetch participants list
    $participants_qry = $conn->query("SELECT a.*, Concat(a.lastname,', ',a.firstname,' ',a.middlename) as name FROM alumnus_bio a INNER JOIN event_commits ec ON a.id = ec.user_id WHERE ec.event_id = $event_id");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Event Details</title>
    <style>
        .avatar {
            display: flex;
            border-radius: 100%;
            width: 100px;
            height: 100px;
            align-items: center;
            justify-content: center;
            border: 3px solid;
            padding: 5px;
        }

        .avatar img {
            max-width: calc(100%);
            max-height: calc(100%);
            border-radius: 100%;
        }

        p {
            margin: unset;
        }

        .hidden {
            display: none;
        }
    </style>
</head>
<body>
    <div class="container-field">
        <div class="col-lg-12">
            <h4>Event Details</h4>
            <hr>
            <div>
                <p>Title: <b><?php echo $event['title']; ?></b></p>
                <p>Schedule: <b><?php echo $event['schedule']; ?></b></p>
                
            </div>
            <hr>
            <h4>Participants List</h4>
            <hr>
            <div class="row">
                <?php while ($participant = $participants_qry->fetch_assoc()): ?>
                    <div class="col-md-4">
                        <center>
                            <div class="avatar">
                                <img src="assets/uploads/<?php echo $participant['avatar']; ?>" class="" alt="">
                            </div>
                        </center>
                        <p>Name: <b><?php echo $participant['name']; ?></b></p>
                        <p>Email: <b><?php echo $participant['email']; ?></b></p>
                    </div>
                <?php endwhile; ?>
            </div>
            <hr>
            <div>
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
   
</body>
</html>
