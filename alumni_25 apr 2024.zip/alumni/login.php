<?php session_start() ?>
<div class="container-fluid" id="login-container">
	<form action="" id="login-frm">
		<div class="form-group">
			<label for="" class="control-label">Email</label>
			<input type="email" name="username" required="" class="form-control">
		</div>
		<div class="form-group">
			<label for="" class="control-label">Password</label>
			<input type="password" name="password" required="" class="form-control">
			<small><a href="index.php?page=signup" id="new_account">Create New Account</a></small>
		</div>
		<div class="btn-group">
			<!--<button type="button" class="close" id="close-btn" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>-->
			<button type="submit" class="button btn btn-info btn-sm">Login</button>
		</div>
	</form>
</div>

<!--<style>
	#login-container {
		display: none;
		position: fixed;
		top: 0;
		left: 0;
		width: 100%;
		height: 100%;
		background-color: rgba(255, 255, 255, 0.8);
		/* Background color with opacity */
		z-index: 9999;
	}

	#login-frm {
		position: absolute;
		top: 50%;
		left: 50%;
		transform: translate(-50%, -50%);
		background-color: white;
		padding: 20px;
		border-radius: 5px;
		z-index: 10000;
		/* Ensure form is on top */
	}
</style>-->

<script>
	$(document).ready(function () {
		$('#close-btn').click(function () {
			$('#login-container').hide();
		});

		$('#login-frm').submit(function (e) {
			e.preventDefault();
			$('#login-frm button[type="submit"]').attr('disabled', true).html('Logging in...');
			if ($(this).find('.alert-danger').length > 0)
				$(this).find('.alert-danger').remove();
			$.ajax({
				url: 'admin/ajax.php?action=login2',
				method: 'POST',
				data: $(this).serialize(),
				error: err => {
					console.log(err);
					$('#login-frm button[type="submit"]').removeAttr('disabled').html('Login');
				},
				success: function (resp) {
					if (resp == 1) {
						location.href = '<?php echo isset($_GET['redirect']) ? $_GET['redirect'] : 'index.php?page=home' ?>';
					} else if (resp == 2) {
						$('#login-frm').prepend('<div class="alert alert-danger">Your account is not yet verified.</div>');
						$('#login-frm button[type="submit"]').removeAttr('disabled').html('Login');
					} else {
						$('#login-frm').prepend('<div class="alert alert-danger">Email or password is incorrect.</div>');
						$('#login-frm button[type="submit"]').removeAttr('disabled').html('Login');
					}
				}
			});
		});
	});
</script>